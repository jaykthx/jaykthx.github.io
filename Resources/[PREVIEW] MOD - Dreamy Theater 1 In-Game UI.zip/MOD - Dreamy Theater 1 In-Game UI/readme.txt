[PREVIEW] Dreamy Theater 1 In-Game UI

This is a UI mod for Project DIVA Mega Mix+.
Please avoid using this mod on console titles, as it will not work as intended.
Thank you to BroGamer for creating the plugin used in this mod.
Other UI mods, such as the FT UI Mod, are unlikely to work with this correctly.
Use at your own discretion.